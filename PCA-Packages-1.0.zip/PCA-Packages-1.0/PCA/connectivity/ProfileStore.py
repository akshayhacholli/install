# IBM Confidential
#
from pyspark import  SparkContext
from pyspark.sql import SQLContext

class ProfileStore:
	
    """ This class provides access to the database where profiles are stored. It also provides convenient methods to access 
	the tables .
    """
    STORE_NAME='dashDB'
    def __init__(self, sc, configStore):
    	self.sc = sc
        self.sqlContext = SQLContext(sc)
        self.configStore = configStore
        self.get_store_details()
        
    def get_store_details(self):
        try:
            credentials = self.configStore.get_credentials(self.STORE_NAME)
            self.url = credentials['jdbcurl']
            self.user = credentials['username']
            self.password = credentials['password']
            #Connect to the DashDB
            self.complete_url = '{0}:user={1};password={2};'.format(self.url, self.user, self.password)
        except Exception as e:
            print "Error occurred while obtaining the connection details"
            print e.__doc__
            print e.message
            raise
       
    def refresh(self):
        self.get_store_details()
        
    #readData from a table
    def readDataFromTable(self, table_name):
        try:
            return self.sqlContext.read.format('jdbc').options(url=self.complete_url,currentSchema=self.user ,dbtable=table_name).load()
        except Exception as e:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.readDataFromTable(table_name)
            else:    
                print "Please Check the Table Name, we were not able to connect to the table"
                print e.__doc__
                print e.message
                raise
    def readDataFromTableUsingQuery(self, table_query):
        try:
            return self.sqlContext.read.format('jdbc').options(url=self.complete_url,currentSchema=self.user ,dbtable='(' + table_query + ')').load()
        except Exception as e:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.readDataFromTableUsingQuery(table_query)
            else:
                print "Please Check the Select Query, we were not able to connect to the table"
                print e.__doc__
                print e.message
                raise
    #insert an dataframe into a table
    def insertDataIntoTable(self, table_name, input_data_frame): 
        try:
            input_data_frame.write.jdbc(url=self.complete_url, table=table_name, mode="append")
        except Exception as e:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.insertDataIntoTable(table_name, input_data_frame)
            else:
                print "We were not able to insert the DF into the Table, Please check the table and the DF format"
                print e.__doc__
                print e.message
                raise
    #convert csv into dataframe based on a table schema
    def convertCSVIntoTableDataFrame(self, csvFile, table_name, delimeter_char = "|"):
        tempTableName = "table_"+table_name
        dataFile = self.sc.textFile(csvFile)
        csvHeaderRow = dataFile.first()
        csvDataRows = dataFile.filter(lambda x: x!=csvHeaderRow)
        csvDataColumns = csvDataRows.map(lambda d: d.split(delimeter_char))
        schema = self.readDataFromTable(table_name).schema

        def mapToDataType(values):
            new_column = []
            for index in range(len(values)):
                new_value = values[index]
                data_type = schema.fields[index].dataType
                new_value.strip()
                if(data_type == IntegerType()):
                    new_value = int(new_value) if new_value else None
                elif(data_type == DoubleType()):
                    new_value = float(new_value) if new_value else None
                elif(data_type == TimestampType() or data_type == DateType()):
                    new_value = parse(new_value) if new_value else None
                new_column.append(new_value)
            for index in range(len(values), len(schema.fields)):
                new_column.append(None)
            return new_column    
        csvDataColumnMap = csvDataColumns.map(mapToDataType)
        csvDF = self.sqlContext.createDataFrame(csvDataColumnMap, schema)
        return csvDF