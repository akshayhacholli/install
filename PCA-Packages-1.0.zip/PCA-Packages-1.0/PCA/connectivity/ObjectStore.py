# IBM Confidential
#
from pyspark import  SparkContext
from pyspark.sql import SQLContext

class ObjectStore:
    """Class that provides access to an object store, the object store can be another object store that is not attached
    with the current spark instance. For the time being this class assumes access to a single remote object store and register
    its credentials under the name 'PCA'. A possible enhancement would be to use the object store label to register its credentials,
    However the label should not contain space or special characters.  
    """
    STORE_NAME='Object-Storage'
    PROVIDER = 'PCA'

    def __init__(self,sc, configStore):
        self.sc =sc
        self.sqlContext = SQLContext(sc)
        self.configStore = configStore
        self.get_store_details()
        
    def get_store_details(self):
            credentials = self.configStore.get_credentials(self.STORE_NAME)
#             print 'using credentials: '
#             print credentials    
            self.set_hadoop_config(credentials)            
    
    def set_hadoop_config(self, creds):
        prefix = "fs.swift.service." + self.PROVIDER
        hconf = self.sc._jsc.hadoopConfiguration()
        hconf.set(prefix + ".auth.url", creds['auth_url'] + '/v2.0/tokens')
        hconf.set(prefix + ".auth.endpoint.prefix", "endpoints")
        hconf.set(prefix + ".tenant", creds['projectId'])
        hconf.set(prefix + ".username", creds['userId'])
        hconf.set(prefix + ".password", creds['password'])
        hconf.setInt(prefix + ".http.port", 8080)
        hconf.set(prefix + ".region", creds['region'])
        hconf.setBoolean(prefix + ".public", True) 
    
    def refresh(self):
        self.get_store_details()
        
    #get the location of file stored in notebooks container of the the objectstore  
    def get_file(self, file_name):
            return 'swift://notebooks.{0}/{1}'.format(self.PROVIDER, file_name)
            
    #get the location of file stored in a specific container in the objectstore
    def get_file_from(self, file_name, container ):
            return 'swift://{0}.{1}/{2}'.format(container, self.PROVIDER, file_name)
       
    #get the location of file stored in notebooks container of the the objectstore
    def read_file(self, file_name):
        try:
            return self.sqlContext.read.json('swift://notebooks.{0}/{1}'.format(self.PROVIDER, file_name))

        except Exception as e:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.read_file(file_name)
            else:
                print "Please Check the file exist in the object store"
                print e.__doc__
                print e.message
                raise
    
    #get the location of file stored in a specific container in the objectstore
    def read_file_from(self, file_name, container):
        try:
            return self.sqlContext.read.json('swift://{0}.{1}/{2}'.format(container, self.PROVIDER, file_name))
        except Exception as e:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.read_file(container, file_name)
            else:
                print "Please Check the file exist in the object store"
                print e.__doc__
                print e.message
                raise