# IBM Confidential
#

from pyspark import  SparkContext
from pyspark.sql import SQLContext
from cloudant.account import Cloudant
from cloudant.account import CloudantException
from PCA.connectivity import ProfileStore
from PCA.connectivity import ObjectStore
from PCA.connectivity import MetadataStore

class ConfigStore:
    """ 
    A class that : reads configuration store details from object store and intializes it. it provides method to retrieve services details from the 
    configuration store.
    """    
 
    CONFIG_REPO_FILE ='swift://notebooks.spark/config-repo.json'

    def __init__(self, sc, config_file=None):
        self.sc = sc   
        self.sqlContext = SQLContext(sc)
        
        if config_file == None:
            self.config_file = self.CONFIG_REPO_FILE
        else:
            self.config_file = 'swift://notebooks.spark/{}'.format(config_file)
        
        self.load_repo()
    
    def bootstrap(self):
        try:
            df = self.sqlContext.read.json(self.config_file)
            self.configStore = df.first()
        except Exception as e:
            print "Error occurred while obtaining Config store credentials from Object store"
            print e.message
            raise             
                     
    def init_config_repo(self):
        try:
            cloudant_client = Cloudant(self.configStore['username'],self.configStore['password'], url=self.configStore['url'])
            cloudant_client.connect()  
        except Exception as e:
            print "Error occurred while trying to connect to config store"
            print e.message
            raise 
        try:
            config_repo = cloudant_client[self.configStore['tenantId']] 
            self.tenant_config = config_repo[self.configStore['tenantId']]  
        except KeyError, e:
            print'Config cloudant database/document does not exist for tenant {}'.format(self.configStore['tenantId'])
            raise
        finally:
            cloudant_client.disconnect()  
 
   
    def load_repo(self):        
        self.bootstrap()            
        self.init_config_repo()
            
    def refresh(self):
        self.load_repo()
    
    def get_service(self, name):
        try:
            vcapservices = self.tenant_config['VCAP_SERVICES']
            return vcapservices[name]
        except Exception as e:
                print'Service {} unavailable for tenant {}'.format(name, self.configStore['tenantId'])
                raise

    def check_service(self, name):
        #backup the service credentials
        backup_credentials= self.get_credentials(name)
        self.refresh()
        new_credentials = self.get_credentials(name)
        return (cmp(new_credentials, backup_credentials)!=0 )
              
    def get_credentials(self, name):
        service = self.get_service(name)
        if service is not None :
            return service['credentials']
      
    def get_tenant(self):
        return self.configStore['tenantId']
    
    def getProfileStore(self):
        return ProfileStore.ProfileStore(self.sc, self)
    
    def getMetadataStore(self):
        return MetadataStore.MetadataStore(self)
    
    def getObjectStore(self):
        return ObjectStore.ObjectStore(self.sc, self)
                        