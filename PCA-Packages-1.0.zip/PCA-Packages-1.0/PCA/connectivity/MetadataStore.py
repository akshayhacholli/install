# IBM Confidential
#
from pyspark.sql import SQLContext
from cloudant.account import Cloudant
from cloudant.account import CloudantException
from requests.exceptions import HTTPError
import json

class MetadataStore:
    
    """
     Class to manage the metadata store, it provides convenient method to create and manipulate both database and documents in
     the metadatastore
    """
    STORE_NAME='cloudantNoSQLDB'
    def __init__(self, configStore):
        self.configStore =configStore
        self.get_store_details()
    
    def get_store_details(self):
        credentials = self.configStore.get_credentials(self.STORE_NAME)
        self.cloudant_client = Cloudant(credentials['username'], credentials['password'], url=credentials['url'])
        try:
            self.cloudant_client.connect()
        except Exception as e:
            print "Connetion to Cloudant DB failed, Please Check credentials"
            print e.__doc__
            print e.message
            raise
    
    def refresh(self):
        self.cloudant_client.disconnect()
        self.get_store_details()
                                                                                                        
                                                                                                          
    def delete_create_database(self, db_name):
        try:
            self.cloudant_client.delete_database(db_name)
        except HTTPError:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.cloudant_client.delete_database(db_name)
        except CloudantException, e:
            pass
        finally:
            return self.cloudant_client.create_database(db_name)
        print 'Created cloudant db', '"{}"'.format(db_name)
        
        
    def init_create_database(self, db_name):
        try:
            self.cloudant_client[db_name]
        except HTTPError:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.cloudant_client.init_create_database(db_name)
        except CloudantException, e:
            pass
        except KeyError, e:
            print' cloudant database does not exist, Creating the database ', db_name
            self.cloudant_client.create_database(db_name)
        finally:
            return self.cloudant_client[db_name]
        
    
    
    def get_database(self, db_name):
        try:
            cloudant_db = self.cloudant_client[db_name]
    
        except HTTPError:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.get_db(db_name)
        except KeyError, e:
            print' %s cloudant database does not exist, Creating the database', db_name
            self.cloudant_client.create_database(db_name)
            cloudant_db = self.cloudant_client[db_name]
   
        return cloudant_db        
  
    def upsert_document(self, document, cloudant_db):
        try:
            existing_document = cloudant_db[document['_id']]  
                                                                                                                    
            print 'updating document : ', 
            print json.dumps(existing_document, indent=4)
        
            existing_document.update(document)
            existing_document.save()
        except HTTPError:
            if self.configStore.check_service(self.STORE_NAME):
                self.refresh()
                self.upsert_document(document, cloudant_db)                                                                                             
        except KeyError, e:
            print 'document does not exist, Creating the document : '
            print json.dumps(document, indent=4)
            cloudant_db.create_document(document)
    
    def shutdown(self):
        self.cloudant_client.disconnect()                                                                                                           