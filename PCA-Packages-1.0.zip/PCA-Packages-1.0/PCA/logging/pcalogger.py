 # IBM Confidential
 #
 # OCO Source Materials
 #
 # IBM Business Analytics: Signature Solutions Foundation
 #
 # (C) Copyright IBM Corp. 2013, 2014
 #
 # The source code for this program is not published or otherwise divested
 # of its trade secrets, irrespective of what has been deposited with the
 # U.S. Copyright Office.

""" 
Custom logging classes used by PCA notebooks to log to object store using cloudant as log records holder 
 
"""
import logging
from cloudant.account import Cloudant
from cloudant.account import CloudantException
from pyspark.sql import SQLContext
import json

class PCAHandler(logging.Handler):
    """
    A class that :
    creates an log database in cloudant with the provided file name
    stores record logs in cloudant,
    when close is called it will store the log records in Object store, then delete the cloudant database
    """
    
    def __init__(self, sc, filename, cloudant_opt, objectstore_opt):
        logging.Handler.__init__(self)     
        
        self.sc = sc
        self.filename = filename
        self.log_db_name = filename.replace('.','_')       
        
        self.cloudant_opt = cloudant_opt
        self.init_cloudant_client( cloudant_opt)
        
        self.objectstore_opt = objectstore_opt
        self.init_objectstore(sc, objectstore_opt)

    def delete_and_create_cloudantdb(self, db_name):
        try:
             self.cloudant_client.delete_database(db_name)
        except CloudantException, e:
            pass
        finally:
            self.cloudant_client.create_database(db_name)
      
    #init cloudant connection
    def init_cloudant_client(self, cloudant_opt):
        cloudant_client = Cloudant(cloudant_opt['cloudant.username'], cloudant_opt['cloudant.password'], url=cloudant_opt['cloudant.url'])
        self.cloudant_client = cloudant_client
        cloudant_client.connect()        
        self.delete_and_create_cloudantdb(self.log_db_name)
        self.logging_db = cloudant_client[self.log_db_name] 
               
    #init object store
    def init_objectstore(self, sc, objectstore_opt):
        self.sqlContext = SQLContext(sc)
        self.set_hadoop_config(objectstore_opt)    
    
        
    def emit(self, record):
        frecord = self.format(record)
    
        try:
            self._save_log(frecord)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            # All errors end here.
            self.handleError(record)
    
    def _save_log(self, frecord) :
        
        self.logging_db.create_document(frecord)
        
        
    
    def flush(self):
        #print 'flushing cloudant content to object store'
        FILE_SWIFT_PATH = 'swift://{0}.{1}/{2}'
        path = FILE_SWIFT_PATH.format(self.objectstore_opt['container'], self.objectstore_opt['name'], self.filename)

        log_df = self.sqlContext.read.format("com.cloudant.spark").options(**self.cloudant_opt).load(self.log_db_name)
        os_df = log_df.select('level','message','timestamp').orderBy('timestamp')
        #os_df.show()
        os_df.coalesce(1).write.mode('overwrite').options(**self.objectstore_opt).json(path)
    
    def close(self):
        try:
            #print 'closing pca handler'
            self.logging_db.delete()
            self.cloudant_client.disconnect()

        finally:
            logging.Handler.close(self)    

    #my object store configuration, this is temp here, it will be replaced by the connection api
    def set_hadoop_config(self, creds):
        prefix = "fs.swift.service." + creds['name']
        hconf = self.sc._jsc.hadoopConfiguration()
        hconf.set(prefix + ".auth.url", creds['auth_url'] + '/v2.0/tokens')
        hconf.set(prefix + ".auth.endpoint.prefix", "endpoints")
        hconf.set(prefix + ".tenant", creds['project_id'])
        hconf.set(prefix + ".username", creds['user_id'])
        hconf.set(prefix + ".password", creds['password'])
        hconf.setInt(prefix + ".http.port", 8080)
        hconf.set(prefix + ".region", creds['region'])
        hconf.setBoolean(prefix + ".public", True) 
   
    
      
class PCAFormatter(logging.Formatter):
    """
    A class that formats log records
    """
    def __init__(self, fmt):
         super(PCAFormatter, self).__init__(fmt)
 
    def format(self, record):
        message = logging.Formatter.format(self, record)
        data = {
                'timestamp': record.asctime,
                'level': record.levelname,
                'message': message
                }
 
        return data
   