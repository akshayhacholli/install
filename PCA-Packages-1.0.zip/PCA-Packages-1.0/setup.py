from setuptools import setup,find_packages
setup(
  name = 'PCA',
  packages = find_packages(), # this must be the same as the name above
  version = '1.0',
  description = 'Library Requried for PCA spark notebooks',
  author = 'Notebook Platform Team',
  author_email = 'vrgunapa@us.ibm.com',
  keywords = [], # arbitrary keywords
  classifiers = []
)